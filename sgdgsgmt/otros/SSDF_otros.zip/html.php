<?php
/*

  File: html.php
  Author: Chris
  Date: 2000/12/14

  scg: Copyright Chris Vincent <cvincent@project802.net>

  You should have received a copy of the GNU Public
  License along with this package; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA 02111-1307, USA.

  Customizaci�n: Sa�l E Morales Cedillo (ccedillo@df.gob.mx)
  Direcci�n de Nuevas Tecnolog�as
  Coordinaci�n Ejecutiva de Desarrollo Inform�tico
  GDF - M�xico - Septiembre 2002

*/
$default->table_border		= "0";
$default->table_header_bg	= "#C0C0C0";
$default->table_cell_bg		= "#C0C0C0";
$default->table_bgcolor					= "#000000";
$default->table_expand_width		= "90%";
$default->table_collapse_width	= "50%";
$default->body_bgcolor		= "#C0C0C0";
$default->body_textcolor	= "#000066";
$default->body_link     	= "#000000";
$default->body_vlink    	= "#000000";
$default->body_width    	= "90%";
$default->styles		= "$default->scg_root_url/includes/styles.css";
?>
