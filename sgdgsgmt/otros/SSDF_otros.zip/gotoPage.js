<!-- Begin
function gotoPage(url) {
	if ((url!="") && (url!="#")) {
		location.href=url;
	}
}
//  End -->