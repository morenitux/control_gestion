<?php
print("onLoad=\"");
switch ($control_catalogos) {
	case "1":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',900,500,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "2":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',700,400,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "3":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',600,400,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "4":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',600,400,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "5":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',900,500,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "6":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',700,400,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "7":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',600,400,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "8":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',600,400,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
	case "9":
		print("newWindow('admin/admonCatalogo.php?sess=$sess&control_catalogos=$control_catalogos',600,500,'Principal','control_catalogos','ventana_auxiliar');\n");
	break;
}
?>
";